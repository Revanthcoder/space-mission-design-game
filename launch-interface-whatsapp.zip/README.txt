Launch interface source files

Contains selected source files for the mission launch interface.
Paths inside the archive are relative to the project root.
Extract the src folder contents into the project to preserve paths.
